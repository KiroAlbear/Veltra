"use client";

import { useVeltra, canDo, type Document as VeltraDocument } from "@/lib/veltra-store";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter, DialogTrigger } from "@/components/ui/dialog";
import { cn } from "@/lib/utils";
import { Shield, Plus, FileText, Package, Clock, RefreshCw, MessageCircle, Mail, MapPin, AlertTriangle, Check, X, Send, ArrowRight, ExternalLink } from "lucide-react";
import { useState } from "react";
import { formatDate, formatRelativeTime } from "@/lib/veltra-store";
import { FadeIn, StaggerGroup, StaggerItem } from "./motion";
import { useToast } from "@/hooks/use-toast";

const CLAIM_STATUS: Record<string, { label: string; className: string }> = {
  pending: { label: "Pending", className: "bg-amber-500/10 text-amber-300 border-amber-500/20" },
  submitted: { label: "Submitted", className: "bg-blue-500/10 text-blue-300 border-blue-500/20" },
  approved: { label: "Approved", className: "bg-emerald-500/10 text-emerald-300 border-emerald-500/20" },
  rejected: { label: "Rejected", className: "bg-red-500/10 text-red-300 border-red-500/20" },
  paid: { label: "Paid", className: "bg-emerald-500/10 text-emerald-300 border-emerald-500/20" },
};

const DOC_TYPE_ICON: Record<string, string> = {
  xray: "🖼️", "lab-report": "🧪", prescription: "💊", consent: "📝", other: "📄",
};

export function ClaimsScreen() {
  const claims = useVeltra((s) => s.insuranceClaims);
  const patients = useVeltra((s) => s.patients);
  const role = useVeltra((s) => s.currentUser?.role);
  const canSubmit = canDo(role, "canConfirm"); // anyone who can confirm can submit claims
  const submitClaim = useVeltra((s) => s.submitClaim);
  const updateClaimStatus = useVeltra((s) => s.updateClaimStatus);
  const selectPatient = useVeltra((s) => s.selectPatient);
  const { toast } = useToast();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [form, setForm] = useState({ patientId: "", provider: "", policyNumber: "", serviceType: "", amount: "", notes: "" });

  const handleAdd = () => {
    if (!form.patientId || !form.provider || !form.amount) {
      toast({ title: "Missing fields", variant: "destructive" });
      return;
    }
    const patient = patients.find((p) => p.id === form.patientId);
    submitClaim({
      patientId: form.patientId,
      patientName: patient?.name || "",
      provider: form.provider,
      policyNumber: form.policyNumber,
      serviceType: form.serviceType,
      amount: Number(form.amount),
      notes: form.notes,
    });
    setDialogOpen(false);
    setForm({ patientId: "", provider: "", policyNumber: "", serviceType: "", amount: "", notes: "" });
    toast({ title: "Claim submitted ✓", description: `${form.provider} — $${form.amount}` });
  };

  return (
    <div className="min-h-screen veltra-ambient">
      <div className="mx-auto max-w-5xl px-8 py-10 sm:px-12 sm:py-14">
        <FadeIn>
          <header className="mb-10">
            <div className="flex items-center justify-between">
              <div>
                <div className="flex items-center gap-2 mb-3">
                  <Shield className="h-3.5 w-3.5 text-veltra-emerald" />
                  <span className="text-micro text-veltra-emerald">Insurance Claims</span>
                </div>
                <h1 className="text-[2.5rem] leading-[1.05] tracking-[-0.035em] text-foreground font-semibold">
                  <span className="text-editorial-italic text-muted-foreground">Every claim,</span>{" "}
                  tracked.
                </h1>
                <p className="text-body text-muted-foreground mt-3">
                  {claims.length} claims · {claims.filter((c) => c.status === "pending" || c.status === "submitted").length} pending · ${claims.filter((c) => c.status === "approved" || c.status === "paid").reduce((s, c) => s + c.amount, 0).toLocaleString()} approved
                </p>
              </div>
              {canSubmit && (
                <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
                  <DialogTrigger asChild>
                    <Button className="h-10 px-5 bg-veltra-emerald hover:bg-veltra-emerald-dark text-white">
                      <Plus className="mr-1.5 h-4 w-4" /> New claim
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="sm:max-w-md veltra-shadow-lg">
                    <DialogHeader>
                      <DialogTitle className="text-title">Submit insurance claim</DialogTitle>
                      <DialogDescription className="text-caption">Claim tracks from submission to payment.</DialogDescription>
                    </DialogHeader>
                    <div className="space-y-3 py-2">
                      <div className="space-y-1.5">
                        <Label className="text-micro text-muted-foreground">Patient</Label>
                        <Select value={form.patientId} onValueChange={(v) => setForm({ ...form, patientId: v })}>
                          <SelectTrigger className="h-10"><SelectValue placeholder="Select..." /></SelectTrigger>
                          <SelectContent>{patients.map((p) => <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>)}</SelectContent>
                        </Select>
                      </div>
                      <div className="grid grid-cols-2 gap-3">
                        <div><Label className="text-micro text-muted-foreground">Provider</Label><Input value={form.provider} onChange={(e) => setForm({ ...form, provider: e.target.value })} placeholder="Bupa Arabia" className="h-10 mt-1" /></div>
                        <div><Label className="text-micro text-muted-foreground">Policy #</Label><Input value={form.policyNumber} onChange={(e) => setForm({ ...form, policyNumber: e.target.value })} placeholder="BUPA-2024-001" className="h-10 mt-1" /></div>
                      </div>
                      <div className="grid grid-cols-2 gap-3">
                        <div><Label className="text-micro text-muted-foreground">Service</Label><Input value={form.serviceType} onChange={(e) => setForm({ ...form, serviceType: e.target.value })} placeholder="Consultation" className="h-10 mt-1" /></div>
                        <div><Label className="text-micro text-muted-foreground">Amount $</Label><Input type="number" value={form.amount} onChange={(e) => setForm({ ...form, amount: e.target.value })} placeholder="450" className="h-10 mt-1" /></div>
                      </div>
                    </div>
                    <DialogFooter>
                      <Button variant="ghost" onClick={() => setDialogOpen(false)} className="h-10">Cancel</Button>
                      <Button onClick={handleAdd} className="h-10 bg-veltra-emerald hover:bg-veltra-emerald-dark text-white">Submit</Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>
              )}
            </div>
          </header>
        </FadeIn>

        <StaggerGroup>
          <Card className="veltra-shadow border-0 bg-card/50 backdrop-blur-sm overflow-hidden">
            {claims.map((claim, idx) => {
              const cfg = CLAIM_STATUS[claim.status];
              return (
                <StaggerItem key={claim.id}>
                  <div className={cn("flex items-center gap-4 px-6 py-4 veltra-transition hover:bg-foreground/[0.03]", idx !== claims.length - 1 && "border-b border-border/40")}>
                    <button onClick={() => selectPatient(claim.patientId)} className="flex-1 min-w-0 text-left group">
                      <p className="text-body font-medium text-foreground truncate group-hover:text-veltra-emerald veltra-transition">{claim.patientName}</p>
                      <p className="text-caption text-muted-foreground truncate">{claim.provider} · {claim.policyNumber} · {claim.serviceType}</p>
                    </button>
                    <div className="text-right flex-shrink-0">
                      <p className="text-body font-semibold tabular text-foreground">${claim.amount}</p>
                      <p className="text-micro text-muted-foreground/70 normal-case tracking-normal mt-0.5">{formatRelativeTime(claim.submittedAt)}</p>
                    </div>
                    <Badge variant="outline" className={cn("text-micro font-medium border", cfg.className)}>{cfg.label}</Badge>
                    {canSubmit && (claim.status === "pending" || claim.status === "submitted") && (
                      <Button size="sm" variant="ghost" onClick={() => { updateClaimStatus(claim.id, "approved"); toast({ title: "Claim approved ✓" }); }} className="h-7 px-2 text-caption text-emerald-400 hover:bg-emerald-500/10">
                        <Check className="h-3 w-3" />
                      </Button>
                    )}
                    {canSubmit && (claim.status === "pending" || claim.status === "submitted") && (
                      <Button size="sm" variant="ghost" onClick={() => { updateClaimStatus(claim.id, "rejected"); toast({ title: "Claim rejected" }); }} className="h-7 px-2 text-caption text-red-400 hover:bg-red-500/10">
                        <X className="h-3 w-3" />
                      </Button>
                    )}
                    {canSubmit && claim.status === "approved" && (
                      <Button size="sm" variant="ghost" onClick={() => { updateClaimStatus(claim.id, "paid"); toast({ title: "Marked as paid ✓" }); }} className="h-7 px-2 text-caption text-emerald-400 hover:bg-emerald-500/10">
                        Pay
                      </Button>
                    )}
                  </div>
                </StaggerItem>
              );
            })}
          </Card>
        </StaggerGroup>
      </div>
    </div>
  );
}

// ===== Inventory Screen =====
export function InventoryScreen() {
  const medications = useVeltra((s) => s.medications);
  const adjustStock = useVeltra((s) => s.adjustMedicationStock);
  const { toast } = useToast();

  const lowStock = medications.filter((m) => m.stock <= m.minStock);

  return (
    <div className="min-h-screen veltra-ambient">
      <div className="mx-auto max-w-5xl px-8 py-10 sm:px-12 sm:py-14">
        <FadeIn>
          <header className="mb-10">
            <div className="flex items-center gap-2 mb-3">
              <Package className="h-3.5 w-3.5 text-veltra-emerald" />
              <span className="text-micro text-veltra-emerald">Pharmacy Inventory</span>
            </div>
            <h1 className="text-[2.5rem] leading-[1.05] tracking-[-0.035em] text-foreground font-semibold">
              <span className="text-editorial-italic text-muted-foreground">Every pill,</span>{" "}
              counted.
            </h1>
            <p className="text-body text-muted-foreground mt-3">
              {medications.length} medications · {lowStock.length} low stock · {medications.filter((m) => new Date(m.expiryDate) < new Date(Date.now() + 90 * 86400000)).length} expiring soon
            </p>
          </header>
        </FadeIn>

        {lowStock.length > 0 && (
          <FadeIn delay={0.05}>
            <Card className="p-4 mb-6 border-amber-500/20 bg-amber-500/5 veltra-shadow border">
              <div className="flex items-center gap-3">
                <AlertTriangle className="h-4 w-4 text-amber-400 flex-shrink-0" />
                <p className="text-caption text-amber-300">
                  {lowStock.length} medications below minimum stock: {lowStock.map((m) => m.name).join(", ")}
                </p>
              </div>
            </Card>
          </FadeIn>
        )}

        <StaggerGroup className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {medications.map((med) => {
            const isLow = med.stock <= med.minStock;
            const expiringSoon = new Date(med.expiryDate) < new Date(Date.now() + 90 * 86400000);
            return (
              <StaggerItem key={med.id}>
                <Card className={cn("p-5 veltra-shadow border-0 bg-card/50 backdrop-blur-sm h-full", isLow && "ring-1 ring-amber-500/30")}>
                  <div className="flex items-start justify-between mb-3">
                    <div>
                      <p className="text-body font-semibold text-foreground">{med.name}</p>
                      <p className="text-caption text-muted-foreground">{med.category} · {med.supplier}</p>
                    </div>
                    {isLow && <AlertTriangle className="h-4 w-4 text-amber-400" />}
                  </div>
                  <div className="flex items-baseline gap-2 mb-3">
                    <p className={cn("text-3xl font-semibold tabular", isLow ? "text-amber-400" : "text-foreground")}>{med.stock}</p>
                    <p className="text-caption text-muted-foreground">{med.unit}</p>
                    <p className="text-micro text-muted-foreground/60 normal-case tracking-normal ml-auto">min: {med.minStock}</p>
                  </div>
                  <div className="space-y-1 pt-3 border-t border-border/40">
                    <div className="flex justify-between text-caption">
                      <span className="text-muted-foreground">Price</span>
                      <span className="text-foreground tabular">${med.price}</span>
                    </div>
                    <div className="flex justify-between text-caption">
                      <span className="text-muted-foreground">Expiry</span>
                      <span className={cn("tabular", expiringSoon ? "text-amber-400" : "text-foreground")}>{med.expiryDate}</span>
                    </div>
                  </div>
                  <div className="flex gap-2 mt-3">
                    <Button size="sm" variant="outline" onClick={() => { adjustStock(med.id, -10); toast({ title: "Dispensed 10 units" }); }} className="flex-1 h-8 text-caption veltra-shadow border-0 bg-foreground/[0.04]">
                      -10
                    </Button>
                    <Button size="sm" variant="outline" onClick={() => { adjustStock(med.id, 50); toast({ title: "Restocked +50 units" }); }} className="flex-1 h-8 text-caption veltra-shadow border-0 bg-foreground/[0.04]">
                      +50
                    </Button>
                  </div>
                </Card>
              </StaggerItem>
            );
          })}
        </StaggerGroup>
      </div>
    </div>
  );
}

// ===== Messages (Patient Messages) Screen =====
export function MessagesScreen() {
  const messages = useVeltra((s) => s.whatsappMessages);
  const patients = useVeltra((s) => s.patients);
  const sendWhatsApp = useVeltra((s) => s.sendWhatsApp);
  const selectPatient = useVeltra((s) => s.selectPatient);
  const { toast } = useToast();
  const [sendOpen, setSendOpen] = useState(false);
  const [form, setForm] = useState({ patientId: "", message: "" });

  const handleSend = () => {
    if (!form.patientId || !form.message) { toast({ title: "Missing fields", variant: "destructive" }); return; }
    const patient = patients.find((p) => p.id === form.patientId);
    sendWhatsApp({ patientId: form.patientId, patientName: patient?.name || "", message: form.message });
    setSendOpen(false); setForm({ patientId: "", message: "" });
    toast({ title: "Message sent ✓", description: `To ${patient?.name} · via secure channel` });
  };

  return (
    <div className="min-h-screen veltra-ambient">
      <div className="mx-auto max-w-3xl px-8 py-10 sm:px-12 sm:py-14">
        <FadeIn>
          <header className="mb-10">
            <div className="flex items-center justify-between">
              <div>
                <div className="flex items-center gap-2 mb-3">
                  <MessageCircle className="h-3.5 w-3.5 text-veltra-emerald" />
                  <span className="text-micro text-veltra-emerald">Patient Messages</span>
                </div>
                <h1 className="text-[2.5rem] leading-[1.05] tracking-[-0.035em] text-foreground font-semibold">
                  <span className="text-editorial-italic text-muted-foreground">Conversations,</span>{" "}
                  not calls.
                </h1>
                <p className="text-body text-muted-foreground mt-3">{messages.length} messages · {messages.filter((m) => m.direction === "outbound").length} sent · {messages.filter((m) => m.direction === "inbound").length} received</p>
              </div>
              <Dialog open={sendOpen} onOpenChange={setSendOpen}>
                <DialogTrigger asChild>
                  <Button className="h-10 px-5 bg-veltra-emerald hover:bg-veltra-emerald-dark text-white">
                    <Send className="mr-1.5 h-4 w-4" /> Send
                  </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-md veltra-shadow-lg">
                  <DialogHeader><DialogTitle className="text-title">Send message</DialogTitle></DialogHeader>
                  <div className="space-y-3 py-2">
                    <div className="space-y-1.5">
                      <Label className="text-micro text-muted-foreground">Patient</Label>
                      <Select value={form.patientId} onValueChange={(v) => setForm({ ...form, patientId: v })}>
                        <SelectTrigger className="h-10"><SelectValue placeholder="Select..." /></SelectTrigger>
                        <SelectContent>{patients.map((p) => <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>)}</SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-1.5">
                      <Label className="text-micro text-muted-foreground">Message</Label>
                      <textarea value={form.message} onChange={(e) => setForm({ ...form, message: e.target.value })} placeholder="Reminder: Your appointment is tomorrow at 09:00..." className="w-full h-24 px-3 py-2 rounded-md bg-background/50 border border-border text-body text-foreground resize-none" />
                    </div>
                  </div>
                  <DialogFooter>
                    <Button variant="ghost" onClick={() => setSendOpen(false)} className="h-10">Cancel</Button>
                    <Button onClick={handleSend} className="h-10 bg-veltra-emerald hover:bg-veltra-emerald-dark text-white">Send</Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </div>
          </header>
        </FadeIn>

        <FadeIn delay={0.1}>
          <Card className="p-6 veltra-shadow border-0 bg-card/50 backdrop-blur-sm">
            <div className="space-y-3 max-h-[600px] overflow-y-auto veltra-scrollbar">
              {[...messages].reverse().map((msg) => (
                <div key={msg.id} className={cn("flex", msg.direction === "outbound" ? "justify-end" : "justify-start")}>
                  <div className={cn("max-w-[75%] rounded-2xl px-4 py-3", msg.direction === "outbound" ? "bg-veltra-emerald/15 text-foreground" : "bg-foreground/[0.05] text-foreground")}>
                    <div className="flex items-center gap-2 mb-1">
                      <button onClick={() => selectPatient(msg.patientId)} className="text-micro text-veltra-emerald hover:underline normal-case tracking-normal">{msg.patientName}</button>
                      <span className="text-micro text-muted-foreground/60 normal-case tracking-normal">{formatRelativeTime(msg.timestamp)}</span>
                      {msg.direction === "outbound" && (
                        <span className={cn("text-micro normal-case tracking-normal", msg.status === "read" ? "text-blue-400" : msg.status === "delivered" ? "text-muted-foreground" : "text-muted-foreground/50")}>
                          {msg.status === "read" ? "✓✓" : msg.status === "delivered" ? "✓✓" : "✓"}
                        </span>
                      )}
                    </div>
                    <p className="text-caption text-foreground leading-relaxed">{msg.message}</p>
                  </div>
                </div>
              ))}
              {messages.length === 0 && (
                <div className="text-center py-12">
                  <MessageCircle className="h-5 w-5 text-muted-foreground/40 mx-auto mb-3" />
                  <p className="text-editorial-italic text-caption text-muted-foreground">No messages yet. Conversations start here.</p>
                </div>
              )}
            </div>
          </Card>
        </FadeIn>
      </div>
    </div>
  );
}

// ===== Availability (Doctor Hours) Screen =====
export function AvailabilityScreen() {
  const doctorHours = useVeltra((s) => s.doctorHours);
  const { toast } = useToast();
  const DAYS = ["monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday"] as const;
  const DAY_LABELS: Record<string, string> = { monday: "Mon", tuesday: "Tue", wednesday: "Wed", thursday: "Thu", friday: "Fri", saturday: "Sat", sunday: "Sun" };

  return (
    <div className="min-h-screen veltra-ambient">
      <div className="mx-auto max-w-4xl px-8 py-10 sm:px-12 sm:py-14">
        <FadeIn>
          <header className="mb-10">
            <div className="flex items-center gap-2 mb-3">
              <Clock className="h-3.5 w-3.5 text-veltra-emerald" />
              <span className="text-micro text-veltra-emerald">Doctor Availability</span>
            </div>
            <h1 className="text-[2.5rem] leading-[1.05] tracking-[-0.035em] text-foreground font-semibold">
              <span className="text-editorial-italic text-muted-foreground">Working</span>{" "}
              hours.
            </h1>
            <p className="text-body text-muted-foreground mt-3">{doctorHours.length} doctors · schedules configured</p>
          </header>
        </FadeIn>

        <StaggerGroup>
          {doctorHours.map((dh) => (
            <StaggerItem key={dh.doctorId}>
              <Card className="p-6 mb-4 veltra-shadow border-0 bg-card/50 backdrop-blur-sm">
                <h3 className="text-title text-foreground mb-4">{dh.doctorName}</h3>
                <div className="grid grid-cols-7 gap-2">
                  {DAYS.map((day) => {
                    const hours = dh[day];
                    return (
                      <div key={day} className={cn("rounded-lg p-3 text-center", hours ? "bg-veltra-emerald/5" : "bg-foreground/[0.03]")}>
                        <p className="text-micro text-muted-foreground mb-1">{DAY_LABELS[day]}</p>
                        {hours ? (
                          <>
                            <p className="text-caption font-medium text-foreground tabular">{hours.start}</p>
                            <p className="text-micro text-muted-foreground/60 normal-case tracking-normal">to</p>
                            <p className="text-caption font-medium text-foreground tabular">{hours.end}</p>
                          </>
                        ) : (
                          <p className="text-micro text-muted-foreground/40 normal-case tracking-normal mt-2">Off</p>
                        )}
                      </div>
                    );
                  })}
                </div>
              </Card>
            </StaggerItem>
          ))}
        </StaggerGroup>
      </div>
    </div>
  );
}

// ===== Recurring Appointments Screen =====
export function RecurringScreen() {
  const recurring = useVeltra((s) => s.recurringPatterns);
  const patients = useVeltra((s) => s.patients);
  const createRecurring = useVeltra((s) => s.createRecurring);
  const toggleRecurring = useVeltra((s) => s.toggleRecurring);
  const selectPatient = useVeltra((s) => s.selectPatient);
  const { toast } = useToast();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [form, setForm] = useState({ patientId: "", type: "", frequency: "quarterly" as "weekly" | "monthly" | "quarterly" | "custom", intervalDays: "90", doctor: "Dr. Sarah" });

  const handleAdd = () => {
    if (!form.patientId || !form.type) { toast({ title: "Missing fields", variant: "destructive" }); return; }
    const patient = patients.find((p) => p.id === form.patientId);
    createRecurring({
      patientId: form.patientId, patientName: patient?.name || "", type: form.type,
      frequency: form.frequency, intervalDays: Number(form.intervalDays),
      nextDate: new Date(Date.now() + Number(form.intervalDays) * 86400000).toISOString(),
      doctor: form.doctor,
    });
    setDialogOpen(false); setForm({ patientId: "", type: "", frequency: "quarterly", intervalDays: "90", doctor: "Dr. Sarah" });
    toast({ title: "Recurring appointment created ✓" });
  };

  return (
    <div className="min-h-screen veltra-ambient">
      <div className="mx-auto max-w-4xl px-8 py-10 sm:px-12 sm:py-14">
        <FadeIn>
          <header className="mb-10">
            <div className="flex items-center justify-between">
              <div>
                <div className="flex items-center gap-2 mb-3">
                  <RefreshCw className="h-3.5 w-3.5 text-veltra-emerald" />
                  <span className="text-micro text-veltra-emerald">Recurring Appointments</span>
                </div>
                <h1 className="text-[2.5rem] leading-[1.05] tracking-[-0.035em] text-foreground font-semibold">
                  <span className="text-editorial-italic text-muted-foreground">They come</span>{" "}
                  back.
                </h1>
                <p className="text-body text-muted-foreground mt-3">{recurring.filter((r) => r.active).length} active · {recurring.filter((r) => !r.active).length} paused</p>
              </div>
              <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
                <DialogTrigger asChild>
                  <Button className="h-10 px-5 bg-veltra-emerald hover:bg-veltra-emerald-dark text-white"><Plus className="mr-1.5 h-4 w-4" /> New</Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-md veltra-shadow-lg">
                  <DialogHeader><DialogTitle className="text-title">Create recurring appointment</DialogTitle></DialogHeader>
                  <div className="space-y-3 py-2">
                    <div className="space-y-1.5">
                      <Label className="text-micro text-muted-foreground">Patient</Label>
                      <Select value={form.patientId} onValueChange={(v) => setForm({ ...form, patientId: v })}>
                        <SelectTrigger className="h-10"><SelectValue placeholder="Select..." /></SelectTrigger>
                        <SelectContent>{patients.map((p) => <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>)}</SelectContent>
                      </Select>
                    </div>
                    <div className="grid grid-cols-2 gap-3">
                      <div><Label className="text-micro text-muted-foreground">Type</Label><Input value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value })} placeholder="Diabetic Follow-up" className="h-10 mt-1" /></div>
                      <div className="space-y-1.5">
                        <Label className="text-micro text-muted-foreground">Frequency</Label>
                        <Select value={form.frequency} onValueChange={(v) => { const days = { weekly: "7", monthly: "30", quarterly: "90", custom: "45" } as Record<string, string>; setForm({ ...form, frequency: v as any, intervalDays: days[v] }); }}>
                          <SelectTrigger className="h-10"><SelectValue /></SelectTrigger>
                          <SelectContent><SelectItem value="weekly">Weekly</SelectItem><SelectItem value="monthly">Monthly</SelectItem><SelectItem value="quarterly">Quarterly</SelectItem><SelectItem value="custom">Custom</SelectItem></SelectContent>
                        </Select>
                      </div>
                    </div>
                  </div>
                  <DialogFooter>
                    <Button variant="ghost" onClick={() => setDialogOpen(false)} className="h-10">Cancel</Button>
                    <Button onClick={handleAdd} className="h-10 bg-veltra-emerald hover:bg-veltra-emerald-dark text-white">Create</Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </div>
          </header>
        </FadeIn>

        <StaggerGroup>
          <Card className="veltra-shadow border-0 bg-card/50 backdrop-blur-sm overflow-hidden">
            {recurring.map((rec, idx) => (
              <StaggerItem key={rec.id}>
                <div className={cn("flex items-center gap-4 px-6 py-4 veltra-transition hover:bg-foreground/[0.03]", idx !== recurring.length - 1 && "border-b border-border/40", !rec.active && "opacity-50")}>
                  <RefreshCw className={cn("h-4 w-4 flex-shrink-0", rec.active ? "text-veltra-emerald" : "text-muted-foreground")} />
                  <button onClick={() => selectPatient(rec.patientId)} className="flex-1 min-w-0 text-left group">
                    <p className="text-body font-medium text-foreground truncate group-hover:text-veltra-emerald veltra-transition">{rec.patientName}</p>
                    <p className="text-caption text-muted-foreground">{rec.type} · every {rec.intervalDays} days · {rec.doctor}</p>
                  </button>
                  <div className="text-right flex-shrink-0">
                    <p className="text-micro text-muted-foreground normal-case tracking-normal">Next</p>
                    <p className="text-caption font-medium text-foreground tabular">{formatDate(rec.nextDate)}</p>
                  </div>
                  <Button size="sm" variant="ghost" onClick={() => { toggleRecurring(rec.id); toast({ title: rec.active ? "Paused" : "Resumed" }); }} className="h-7 px-2 text-caption text-muted-foreground hover:text-foreground">
                    {rec.active ? "Pause" : "Resume"}
                  </Button>
                </div>
              </StaggerItem>
            ))}
          </Card>
        </StaggerGroup>
      </div>
    </div>
  );
}

// ===== Documents Screen =====
export function DocumentsScreen() {
  const documents = useVeltra((s) => s.documents);
  const patients = useVeltra((s) => s.patients);
  const uploadDocument = useVeltra((s) => s.uploadDocument);
  const selectPatient = useVeltra((s) => s.selectPatient);
  const currentUser = useVeltra((s) => s.currentUser);
  const { toast } = useToast();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [form, setForm] = useState({ patientId: "", name: "", type: "lab-report" as VeltraDocument["type"], size: "1.2 MB" });

  const handleUpload = () => {
    if (!form.patientId || !form.name) { toast({ title: "Missing fields", variant: "destructive" }); return; }
    const patient = patients.find((p) => p.id === form.patientId);
    uploadDocument({ patientId: form.patientId, patientName: patient?.name || "", name: form.name, type: form.type, uploadedBy: currentUser?.name || "Unknown", size: form.size });
    setDialogOpen(false); setForm({ patientId: "", name: "", type: "lab-report", size: "1.2 MB" });
    toast({ title: "Document uploaded ✓" });
  };

  return (
    <div className="min-h-screen veltra-ambient">
      <div className="mx-auto max-w-4xl px-8 py-10 sm:px-12 sm:py-14">
        <FadeIn>
          <header className="mb-10">
            <div className="flex items-center justify-between">
              <div>
                <div className="flex items-center gap-2 mb-3">
                  <FileText className="h-3.5 w-3.5 text-veltra-emerald" />
                  <span className="text-micro text-veltra-emerald">Documents</span>
                </div>
                <h1 className="text-[2.5rem] leading-[1.05] tracking-[-0.035em] text-foreground font-semibold">
                  <span className="text-editorial-italic text-muted-foreground">Every file,</span>{" "}
                  in place.
                </h1>
                <p className="text-body text-muted-foreground mt-3">{documents.length} documents · {new Set(documents.map((d) => d.patientId)).size} patients</p>
              </div>
              <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
                <DialogTrigger asChild>
                  <Button className="h-10 px-5 bg-veltra-emerald hover:bg-veltra-emerald-dark text-white"><Plus className="mr-1.5 h-4 w-4" /> Upload</Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-md veltra-shadow-lg">
                  <DialogHeader><DialogTitle className="text-title">Upload document</DialogTitle></DialogHeader>
                  <div className="space-y-3 py-2">
                    <div className="space-y-1.5">
                      <Label className="text-micro text-muted-foreground">Patient</Label>
                      <Select value={form.patientId} onValueChange={(v) => setForm({ ...form, patientId: v })}>
                        <SelectTrigger className="h-10"><SelectValue placeholder="Select..." /></SelectTrigger>
                        <SelectContent>{patients.map((p) => <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>)}</SelectContent>
                      </Select>
                    </div>
                    <div className="grid grid-cols-2 gap-3">
                      <div><Label className="text-micro text-muted-foreground">File name</Label><Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="X-Ray.jpg" className="h-10 mt-1" /></div>
                      <div className="space-y-1.5">
                        <Label className="text-micro text-muted-foreground">Type</Label>
                        <Select value={form.type} onValueChange={(v) => setForm({ ...form, type: v as VeltraDocument["type"] })}>
                          <SelectTrigger className="h-10"><SelectValue /></SelectTrigger>
                          <SelectContent><SelectItem value="xray">X-Ray</SelectItem><SelectItem value="lab-report">Lab Report</SelectItem><SelectItem value="prescription">Prescription</SelectItem><SelectItem value="consent">Consent</SelectItem><SelectItem value="other">Other</SelectItem></SelectContent>
                        </Select>
                      </div>
                    </div>
                  </div>
                  <DialogFooter>
                    <Button variant="ghost" onClick={() => setDialogOpen(false)} className="h-10">Cancel</Button>
                    <Button onClick={handleUpload} className="h-10 bg-veltra-emerald hover:bg-veltra-emerald-dark text-white">Upload</Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </div>
          </header>
        </FadeIn>

        <StaggerGroup>
          <Card className="veltra-shadow border-0 bg-card/50 backdrop-blur-sm overflow-hidden">
            {documents.map((doc, idx) => (
              <StaggerItem key={doc.id}>
                <div className={cn("flex items-center gap-4 px-6 py-4 veltra-transition hover:bg-foreground/[0.03]", idx !== documents.length - 1 && "border-b border-border/40")}>
                  <div className="flex-shrink-0 h-10 w-10 rounded-lg bg-foreground/[0.05] flex items-center justify-center text-lg">
                    {DOC_TYPE_ICON[doc.type]}
                  </div>
                  <button onClick={() => selectPatient(doc.patientId)} className="flex-1 min-w-0 text-left group">
                    <p className="text-body font-medium text-foreground truncate group-hover:text-veltra-emerald veltra-transition">{doc.name}</p>
                    <p className="text-caption text-muted-foreground truncate">{doc.patientName} · {doc.uploadedBy} · {formatDate(doc.uploadedAt)}</p>
                  </button>
                  <span className="text-caption text-muted-foreground tabular flex-shrink-0">{doc.size}</span>
                  <Badge variant="outline" className="text-micro font-medium border bg-foreground/[0.05] text-muted-foreground normal-case tracking-normal">{doc.type.replace("-", " ")}</Badge>
                </div>
              </StaggerItem>
            ))}
          </Card>
        </StaggerGroup>
      </div>
    </div>
  );
}
