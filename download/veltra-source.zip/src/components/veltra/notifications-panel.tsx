"use client";

import { useVeltra } from "@/lib/veltra-store";
import { motion, AnimatePresence } from "framer-motion";
import { Bell, X, Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { formatRelativeTime } from "@/lib/veltra-store";

export function NotificationsPanel({
  open,
  onClose,
}: {
  open: boolean;
  onClose: () => void;
}) {
  const notifications = useVeltra((s) => s.notifications);
  const markNotificationRead = useVeltra((s) => s.markNotificationRead);
  const markAllNotificationsRead = useVeltra((s) => s.markAllNotificationsRead);

  const unread = notifications.filter((n) => !n.read);

  return (
    <AnimatePresence>
      {open && (
        <>
          <motion.div
            className="fixed inset-0 z-[55] bg-black/40 backdrop-blur-sm"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
          />
          <motion.div
            className="fixed right-4 top-14 z-[56] w-96 max-w-[calc(100vw-2rem)] bg-card/95 backdrop-blur-2xl rounded-2xl veltra-shadow-lg border border-border/40 overflow-hidden"
            initial={{ opacity: 0, scale: 0.96, y: -8 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.96, y: -8 }}
            transition={{ duration: 0.25, ease: [0.16, 1, 0.3, 1] }}
          >
            {/* Header */}
            <div className="flex items-center justify-between px-5 py-4 border-b border-border/40">
              <div className="flex items-center gap-2">
                <Bell className="h-4 w-4 text-veltra-emerald" />
                <h3 className="text-body font-semibold text-foreground">Notifications</h3>
                {unread.length > 0 && (
                  <span className="text-micro text-veltra-emerald normal-case tracking-normal">
                    {unread.length} new
                  </span>
                )}
              </div>
              <div className="flex items-center gap-1">
                {unread.length > 0 && (
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={markAllNotificationsRead}
                    className="h-7 text-caption text-muted-foreground hover:text-foreground"
                  >
                    Mark all read
                  </Button>
                )}
                <button
                  onClick={onClose}
                  className="h-7 w-7 rounded-md hover:bg-foreground/[0.05] flex items-center justify-center text-muted-foreground hover:text-foreground veltra-transition"
                >
                  <X className="h-3.5 w-3.5" />
                </button>
              </div>
            </div>

            {/* List */}
            <div className="max-h-96 overflow-y-auto veltra-scrollbar">
              {notifications.length === 0 ? (
                <div className="px-5 py-12 text-center">
                  <div className="mx-auto h-10 w-10 rounded-full bg-emerald-500/10 flex items-center justify-center mb-3">
                    <Check className="h-4 w-4 text-emerald-400" />
                  </div>
                  <p className="text-editorial-italic text-caption text-muted-foreground">
                    Nothing needs you. Enjoy the quiet.
                  </p>
                </div>
              ) : (
                notifications.map((n, idx) => (
                  <button
                    key={n.id}
                    onClick={() => markNotificationRead(n.id)}
                    className={cn(
                      "w-full flex gap-3 px-5 py-3.5 text-left veltra-transition hover:bg-foreground/[0.03]",
                      idx !== notifications.length - 1 && "border-b border-border/30",
                      !n.read && "bg-veltra-emerald/[0.03]"
                    )}
                  >
                    <span className={cn("h-2 w-2 rounded-full mt-1.5 flex-shrink-0",
                      n.type === "action" ? "bg-red-500" :
                      n.type === "warning" ? "bg-amber-500" :
                      n.type === "success" ? "bg-emerald-500" : "bg-blue-500"
                    )} />
                    <div className="flex-1 min-w-0">
                      <p className={cn(
                        "text-caption leading-snug",
                        n.read ? "font-normal text-muted-foreground" : "font-medium text-foreground"
                      )}>
                        {n.title}
                      </p>
                      <p className="text-caption text-muted-foreground mt-0.5 leading-snug">
                        {n.description}
                      </p>
                      <p className="text-micro text-muted-foreground/60 mt-1 normal-case tracking-normal">
                        {formatRelativeTime(n.timestamp)}
                      </p>
                    </div>
                  </button>
                ))
              )}
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
