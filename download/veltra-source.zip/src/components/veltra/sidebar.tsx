"use client";

import { useVeltra, canAccessWithTier } from "@/lib/veltra-store";
import { SPECIALTIES } from "@/lib/specialties";
import { TIERS } from "@/lib/subscription-tiers";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Briefcase,
  Users,
  CalendarClock,
  Activity,
  FlaskConical,
  DollarSign,
  BarChart3,
  MessageCircle,
  FileText,
  Package,
  Clock,
  RefreshCw,
  Shield,
  Settings as SettingsIcon,
  LogOut,
  MapPin,
  ChevronDown,
  ChevronRight,
  Bell,
  Menu,
  X,
  Command,
  Sparkles,
  Check,
  Headphones,
} from "lucide-react";
import { useState } from "react";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
  DropdownMenuLabel,
} from "@/components/ui/dropdown-menu";
import { ThemeToggle } from "./theme-toggle";
import { LanguageToggle } from "./language-toggle";
import { SupportChat } from "./support-chat";
import { useToast } from "@/hooks/use-toast";

type NavItem = {
  id: string;
  label: string;
  icon: React.ElementType;
  shortcut: string;
  tip: string;
};

type NavGroup = {
  id: string;
  label: string;
  icon: React.ElementType;
  tip: string;
  items?: NavItem[];
  single?: NavItem;
};

const NAV_GROUPS: NavGroup[] = [
  {
    id: "brief",
    label: "Home",
    icon: Briefcase,
    tip: "Memory brief — your daily morning intelligence",
    single: { id: "brief", label: "Home", icon: Briefcase, shortcut: "1", tip: "Memory brief" },
  },
  {
    id: "patients",
    label: "Patients",
    icon: Users,
    tip: "All patients, timelines, documents, messages",
    items: [
      { id: "patients", label: "All Patients", icon: Users, shortcut: "2", tip: "All patients in this clinic" },
      { id: "timeline", label: "Timeline", icon: Activity, shortcut: "4", tip: "Selected patient's timeline" },
      { id: "labs", label: "Lab Results", icon: FlaskConical, shortcut: "l", tip: "All lab results" },
      { id: "documents", label: "Documents", icon: FileText, shortcut: "d", tip: "Patient documents" },
      { id: "messages", label: "Messages", icon: MessageCircle, shortcut: "m", tip: "Patient messages" },
    ],
  },
  {
    id: "schedule",
    label: "Schedule",
    icon: CalendarClock,
    tip: "Appointments, calendar, recurring, availability",
    items: [
      { id: "appointments", label: "Appointments", icon: CalendarClock, shortcut: "3", tip: "Today's schedule" },
      { id: "calendar", label: "Calendar", icon: CalendarClock, shortcut: "c", tip: "Month view calendar" },
      { id: "recurring", label: "Recurring", icon: RefreshCw, shortcut: "u", tip: "Recurring appointments" },
      { id: "availability", label: "Availability", icon: Clock, shortcut: "a", tip: "Doctor working hours" },
    ],
  },
  {
    id: "operations",
    label: "Operations",
    icon: DollarSign,
    tip: "Billing, insurance, inventory, reports, audit",
    items: [
      { id: "billing", label: "Billing", icon: DollarSign, shortcut: "b", tip: "Payments and balances" },
      { id: "claims", label: "Insurance", icon: Shield, shortcut: "i", tip: "Insurance claims" },
      { id: "inventory", label: "Inventory", icon: Package, shortcut: "p", tip: "Pharmacy stock" },
      { id: "reports", label: "Reports", icon: BarChart3, shortcut: "r", tip: "Insights and trends" },
      { id: "audit", label: "Audit Log", icon: Shield, shortcut: "5", tip: "Action history (admin only)" },
    ],
  },
  {
    id: "settings",
    label: "Settings",
    icon: SettingsIcon,
    tip: "Your account and preferences",
    single: { id: "settings", label: "Settings", icon: SettingsIcon, shortcut: "6", tip: "Your account and preferences" },
  },
];

export function Sidebar({ onNotificationsOpen }: { onNotificationsOpen?: () => void }) {
  const activeView = useVeltra((s) => s.activeView);
  const setView = useVeltra((s) => s.setView);
  const currentUser = useVeltra((s) => s.currentUser);
  const logout = useVeltra((s) => s.logout);
  const notifications = useVeltra((s) => s.notifications);
  const activeTier = useVeltra((s) => s.activeTier);
  const unread = notifications.filter((n) => !n.read).length;
  const [mobileOpen, setMobileOpen] = useState(false);
  const [expandedGroups, setExpandedGroups] = useState<Record<string, boolean>>({});
  const [supportChatOpen, setSupportChatOpen] = useState(false);
  const { toast } = useToast();

  const handleNav = (id: string) => {
    setView(id as any);
    setMobileOpen(false);
  };

  const toggleGroup = (groupId: string) => {
    setExpandedGroups((prev) => ({ ...prev, [groupId]: !prev[groupId] }));
  };

  // Tier-enabled screens (drives what's visible)
  const tierScreens = activeTier?.screensEnabled || [];

  // Check if any item in a group is the active view
  const isGroupActive = (group: NavGroup) => {
    if (group.single) return activeView === group.single.id;
    return group.items?.some((item) => item.id === activeView) ?? false;
  };

  // Filter groups by permissions AND tier
  const visibleGroups = NAV_GROUPS.filter((group) => {
    if (group.single) return canAccessWithTier(currentUser?.role, group.single.id, tierScreens);
    return group.items?.some((item) => canAccessWithTier(currentUser?.role, item.id, tierScreens));
  });

  // Filter items within a group by permissions AND tier
  const getVisibleItems = (group: NavGroup): NavItem[] => {
    if (group.single) return [group.single];
    return (group.items || []).filter((item) => canAccessWithTier(currentUser?.role, item.id, tierScreens));
  };

  const renderNavItem = (item: NavItem) => (
    <button
      key={item.id}
      onClick={() => handleNav(item.id)}
      className={cn(
        "w-full flex items-center gap-3 rounded-lg px-3 py-2 text-body veltra-transition",
        activeView === item.id
          ? "bg-veltra-emerald/15 text-veltra-emerald font-medium"
          : "text-muted-foreground hover:bg-foreground/[0.05] hover:text-foreground"
      )}
    >
      <item.icon className="h-4 w-4 flex-shrink-0" />
      <span className="flex-1 text-left">{item.label}</span>
      <kbd className="text-micro text-muted-foreground/40 normal-case tracking-normal hidden lg:inline">
        {item.shortcut}
      </kbd>
    </button>
  );

  const renderGroup = (group: NavGroup) => {
    // Single item — no expand/collapse
    if (group.single) {
      return (
        <Tooltip key={group.id}>
          <TooltipTrigger asChild>{renderNavItem(group.single)}</TooltipTrigger>
          <TooltipContent side="right" className="bg-card/95 backdrop-blur-xl border-border/40">
            <p className="text-caption">{group.tip}</p>
          </TooltipContent>
        </Tooltip>
      );
    }

    // Group with sub-items
    const visibleItems = getVisibleItems(group);
    if (visibleItems.length === 0) return null;

    const isExpanded = expandedGroups[group.id] || isGroupActive(group);
    const GroupIcon = group.icon;

    return (
      <div key={group.id}>
        <Tooltip>
          <TooltipTrigger asChild>
            <button
              onClick={() => {
                toggleGroup(group.id);
                // Navigate to first visible item if group is active
                if (!isExpanded && visibleItems.length > 0) {
                  handleNav(visibleItems[0].id);
                }
              }}
              className={cn(
                "w-full flex items-center gap-3 rounded-lg px-3 py-2 text-body veltra-transition",
                isGroupActive(group)
                  ? "text-veltra-emerald font-medium"
                  : "text-muted-foreground hover:bg-foreground/[0.05] hover:text-foreground"
              )}
            >
              <GroupIcon className="h-4 w-4 flex-shrink-0" />
              <span className="flex-1 text-left">{group.label}</span>
              {isExpanded ? (
                <ChevronDown className="h-3.5 w-3.5 text-muted-foreground/50" />
              ) : (
                <ChevronRight className="h-3.5 w-3.5 text-muted-foreground/50" />
              )}
            </button>
          </TooltipTrigger>
          <TooltipContent side="right" className="bg-card/95 backdrop-blur-xl border-border/40">
            <p className="text-caption">{group.tip}</p>
          </TooltipContent>
        </Tooltip>

        {/* Sub-items */}
        {isExpanded && (
          <div className="ml-4 mt-0.5 space-y-0.5 border-l border-border/20 pl-3">
            {visibleItems.map((item) => renderNavItem(item))}
          </div>
        )}
      </div>
    );
  };

  return (
    <TooltipProvider delayDuration={400}>
      <>
        {/* Mobile top bar */}
        <div className="md:hidden sticky top-10 z-30 flex h-12 items-center justify-between border-b border-border/40 bg-background/80 backdrop-blur-xl px-4">
          <Button size="sm" variant="ghost" onClick={() => setMobileOpen(true)} className="h-8 w-8 p-0" aria-label="Open navigation">
            <Menu className="h-4 w-4" />
          </Button>
          <span className="text-caption font-medium text-foreground">
            {(() => {
              for (const g of visibleGroups) {
                if (g.single && g.single.id === activeView) return g.single.label;
                const item = g.items?.find((i) => i.id === activeView);
                if (item) return item.label;
              }
              return "Veltra";
            })()}
          </span>
          <div className="flex items-center gap-1">
            <button onClick={() => setSupportChatOpen(true)} className="relative h-8 w-8 flex items-center justify-center rounded-md hover:bg-veltra-emerald/10 hover:text-veltra-emerald veltra-transition" aria-label="Support">
              <Headphones className="h-4 w-4 text-muted-foreground" />
            </button>
            <LanguageToggle />
            <ThemeToggle />
            <button onClick={onNotificationsOpen} aria-label="Notifications" className="relative h-8 w-8 flex items-center justify-center rounded-md hover:bg-foreground/[0.05] veltra-transition">
              <Bell className="h-4 w-4 text-muted-foreground" />
              {unread > 0 && (
                <span className="absolute top-1 right-1 h-3.5 min-w-3.5 rounded-full bg-veltra-emerald text-[9px] font-bold text-white flex items-center justify-center px-1">{unread}</span>
              )}
            </button>
          </div>
        </div>

        {/* Mobile drawer */}
        {mobileOpen && (
          <div className="md:hidden fixed inset-0 z-50 bg-black/60 backdrop-blur-sm" onClick={() => setMobileOpen(false)}>
            <div className="absolute left-0 top-0 h-full w-72 bg-card/95 backdrop-blur-xl shadow-2xl flex flex-col" onClick={(e) => e.stopPropagation()}>
              <div className="flex h-14 items-center justify-between border-b border-border/40 px-5">
                <div className="flex items-center gap-2.5">
                  <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-veltra-emerald text-white text-xs font-bold">V</div>
                  <span className="text-body font-semibold text-foreground">Veltra</span>
                </div>
                <Button size="sm" variant="ghost" onClick={() => setMobileOpen(false)} className="h-8 w-8 p-0" aria-label="Close menu">
                  <X className="h-4 w-4" />
                </Button>
              </div>
              <nav className="flex-1 p-3 overflow-y-auto veltra-scrollbar">
                {visibleGroups.map((group) => renderGroup(group))}
              </nav>
            </div>
          </div>
        )}

        {/* Desktop sidebar */}
        <aside className="hidden md:flex md:w-64 md:flex-col md:border-r md:border-border/40 md:bg-sidebar/50 md:backdrop-blur-xl">
          {/* Brand row — natural place: logo + location + tier (NO logout here) */}
          <div className="flex h-14 items-center gap-2 border-b border-border/40 px-4">
            <button onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })} className="flex items-center gap-2 flex-1 min-w-0">
              <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-veltra-emerald text-white text-xs font-bold flex-shrink-0">V</div>
              <span className="text-body font-semibold tracking-tight text-foreground truncate">Veltra</span>
            </button>
            <LocationSwitcher />
            <TierBadge />
          </div>

          {/* Specialty switcher — investor-friendly demo flipper */}
          <div className="px-3 pt-3 pb-1">
            <SpecialtySwitcher />
          </div>

          {/* Nav — grouped sections (tier-filtered) */}
          <nav className="flex-1 p-3 overflow-y-auto veltra-scrollbar">
            <p className="text-micro text-muted-foreground/60 px-3 mb-2 mt-1">Workspace</p>
            {visibleGroups.map((group) => renderGroup(group))}

            {/* Command palette hint */}
            <button
              onClick={() => window.dispatchEvent(new KeyboardEvent("keydown", { key: "k", metaKey: true }))}
              className="w-full flex items-center gap-3 rounded-lg px-3 py-2 text-body text-muted-foreground hover:bg-foreground/[0.05] hover:text-foreground veltra-transition mt-3"
            >
              <Command className="h-4 w-4" />
              <span className="flex-1 text-left">Search</span>
              <kbd className="text-micro text-muted-foreground/40 normal-case tracking-normal">⌘K</kbd>
            </button>
          </nav>

          {/* Footer — compact */}
          <div className="border-t border-border/40 p-2">
            {/* Support — opens in-app chat */}
            <button onClick={() => setSupportChatOpen(true)} className="w-full flex items-center gap-3 rounded-lg px-3 py-2 text-body text-muted-foreground hover:bg-veltra-emerald/10 hover:text-veltra-emerald veltra-transition mb-1">
              <Headphones className="h-4 w-4" />
              <span className="flex-1 text-left">Support</span>
              <span className="text-micro text-veltra-emerald normal-case tracking-normal flex items-center gap-1">
                <span className="veltra-live-dot" /> Live
              </span>
            </button>
            <button onClick={onNotificationsOpen} className="w-full flex items-center gap-3 rounded-lg px-3 py-2 text-body text-muted-foreground hover:bg-foreground/[0.05] hover:text-foreground veltra-transition">
              <div className="relative">
                <Bell className="h-4 w-4" />
                {unread > 0 && (
                  <span className="absolute -top-1 -right-1 h-3 min-w-3 rounded-full bg-veltra-emerald text-[8px] font-bold text-white flex items-center justify-center px-0.5">{unread}</span>
                )}
              </div>
              <span className="flex-1 text-left">Notifications</span>
              {unread > 0 && <span className="text-micro text-veltra-emerald normal-case tracking-normal">{unread} new</span>}
            </button>

            {/* User — compact, click opens dropdown */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <button className="mt-1.5 w-full flex items-center gap-2 px-2.5 py-2 rounded-lg bg-foreground/[0.04] hover:bg-foreground/[0.07] veltra-transition">
                  <div className={cn("h-7 w-7 rounded-full flex items-center justify-center text-micro font-semibold flex-shrink-0", currentUser?.avatarColor || "bg-foreground/20")}>
                    {currentUser?.initials || "?"}
                  </div>
                  <div className="flex-1 min-w-0 text-left">
                    <p className="text-caption font-medium text-foreground truncate leading-tight">{currentUser?.name || "Not signed in"}</p>
                    <p className="text-micro text-muted-foreground normal-case tracking-normal truncate leading-tight mt-0.5 capitalize">{currentUser?.role || "—"}</p>
                  </div>
                  <LanguageToggle />
                  <ThemeToggle />
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" side="top" className="w-56 veltra-shadow-lg bg-card/95 backdrop-blur-xl border-border/40 mb-2">
                <DropdownMenuLabel className="text-micro text-muted-foreground">{currentUser?.email}</DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={() => handleNav("settings")} className="text-body cursor-pointer">
                  <SettingsIcon className="mr-2 h-3.5 w-3.5" /> Settings
                </DropdownMenuItem>
                {canAccessWithTier(currentUser?.role, "audit", tierScreens) && (
                  <DropdownMenuItem onClick={() => handleNav("audit")} className="text-body cursor-pointer">
                    <Shield className="mr-2 h-3.5 w-3.5" /> Audit log
                  </DropdownMenuItem>
                )}
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={() => { logout(); toast({ title: "Signed out", description: "See you tomorrow." }); }} className="text-body cursor-pointer text-red-400 focus:text-red-400 focus:bg-red-500/10">
                  <LogOut className="mr-2 h-3.5 w-3.5" /> Sign out
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </aside>
      </>

      {/* In-app Support Chat — for signed-in users */}
      <SupportChat open={supportChatOpen} onClose={() => setSupportChatOpen(false)} />
    </TooltipProvider>
  );
}

function LocationSwitcher() {
  const locations = useVeltra((s) => s.locations);
  const currentLocationId = useVeltra((s) => s.currentLocationId);
  const switchLocation = useVeltra((s) => s.switchLocation);
  const current = locations.find((l) => l.id === currentLocationId);

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <button className="ml-auto mr-0 flex items-center gap-1.5 px-2 py-1 rounded-md hover:bg-foreground/[0.05] veltra-transition text-micro text-muted-foreground hover:text-foreground">
          <MapPin className="h-3 w-3" />
          <span className="truncate max-w-[80px]">{current?.name.split(" — ")[0] || "Location"}</span>
        </button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-48 veltra-shadow-lg bg-card/95 backdrop-blur-xl border-border/40">
        <DropdownMenuLabel className="text-micro text-muted-foreground">Locations</DropdownMenuLabel>
        <DropdownMenuSeparator />
        {locations.map((loc) => (
          <DropdownMenuItem key={loc.id} onClick={() => switchLocation(loc.id)} className={cn("text-body cursor-pointer", loc.id === currentLocationId && "text-veltra-emerald")}>
            <MapPin className="mr-2 h-3.5 w-3.5" />
            {loc.name}
            {loc.isPrimary && <Badge variant="secondary" className="ml-auto text-micro normal-case tracking-normal">Primary</Badge>}
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}

function SpecialtySwitcher() {
  const activeSpecialty = useVeltra((s) => s.activeSpecialty);
  const setSpecialty = useVeltra((s) => s.setSpecialty);
  const setView = useVeltra((s) => s.setView);
  const { toast } = useToast();

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <button className={cn(
          "w-full flex items-center gap-2 px-3 py-2 rounded-lg veltra-transition veltra-glass border-0 text-left",
          "hover:scale-[1.01]"
        )}>
          <div className={cn("h-7 w-7 rounded-md flex items-center justify-center text-sm flex-shrink-0", activeSpecialty.color)}>
            {activeSpecialty.emoji}
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-micro text-muted-foreground/70 normal-case tracking-normal leading-none mb-0.5">Specialty demo</p>
            <p className="text-caption font-medium text-foreground truncate">{activeSpecialty.name}</p>
          </div>
          <ChevronDown className="h-3.5 w-3.5 text-muted-foreground/50 flex-shrink-0" />
        </button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="start" side="bottom" className="w-72 max-h-[60vh] overflow-y-auto veltra-scrollbar veltra-shadow-lg bg-card/95 backdrop-blur-xl border-border/40">
        <DropdownMenuLabel className="text-micro text-muted-foreground flex items-center gap-1.5">
          <Sparkles className="h-3 w-3 text-veltra-emerald" />
          Switch specialty demo
        </DropdownMenuLabel>
        <DropdownMenuSeparator />
        {SPECIALTIES.map((s) => (
          <DropdownMenuItem
            key={s.id}
            onClick={() => {
              setSpecialty(s.id);
              setView("brief");
              toast({ title: `Switched to ${s.name}`, description: "Demo data regenerated for this specialty." });
            }}
            className={cn("text-body cursor-pointer gap-2.5", s.id === activeSpecialty.id && "bg-veltra-emerald/10")}
          >
            <span className={cn("h-6 w-6 rounded-md flex items-center justify-center text-xs flex-shrink-0", s.color)}>
              {s.emoji}
            </span>
            <span className="flex-1">{s.name}</span>
            {s.id === activeSpecialty.id && <Check className="h-3.5 w-3.5 text-veltra-emerald" />}
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}

function TierBadge() {
  const activeTier = useVeltra((s) => s.activeTier);
  const setActiveTier = useVeltra((s) => s.setActiveTier);
  const { toast } = useToast();

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <button className={cn("ml-auto mr-0 flex items-center gap-1 px-1.5 py-0.5 rounded-md text-micro font-medium veltra-transition", activeTier.accentColor)}>
          <span className="text-xs">{activeTier.emoji}</span>
          <span className="truncate max-w-[50px] hidden lg:inline">{activeTier.name}</span>
          <ChevronDown className="h-2.5 w-2.5 opacity-60" />
        </button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" side="bottom" className="w-72 veltra-shadow-lg bg-card/95 backdrop-blur-xl border-border/40">
        <DropdownMenuLabel className="text-micro text-muted-foreground flex items-center gap-1.5">
          <Sparkles className="h-3 w-3 text-veltra-emerald" />
          Subscription tier — what's unlocked
        </DropdownMenuLabel>
        <DropdownMenuSeparator />
        {TIERS.map((t) => {
          const isActive = t.id === activeTier.id;
          const locCount = t.limits.locations === "unlimited" ? "∞" : t.limits.locations;
          const userCount = t.limits.users === "unlimited" ? "∞" : t.limits.users;
          const memory = t.limits.memoryRetentionDays === "unlimited" ? "∞" : t.limits.memoryRetentionDays === 90 ? "90d" : t.limits.memoryRetentionDays === 730 ? "2yr" : "∞";
          return (
            <DropdownMenuItem
              key={t.id}
              onClick={() => {
                setActiveTier(t.id);
                toast({
                  title: `Switched to ${t.name}`,
                  description: `${locCount} location${String(locCount) !== "1" ? "s" : ""} · ${userCount} users · ${t.screensEnabled.length} screens unlocked`,
                });
              }}
              className={cn("text-body cursor-pointer gap-2.5 p-3", isActive && "bg-veltra-emerald/10")}
            >
              <span className={cn("h-8 w-8 rounded-md flex items-center justify-center text-sm flex-shrink-0", t.accentColor)}>
                {t.emoji}
              </span>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <p className="text-caption font-semibold text-foreground truncate">{t.name}</p>
                  {t.badge && (
                    <span className="text-micro px-1.5 py-0 rounded bg-veltra-emerald/15 text-veltra-emerald normal-case tracking-normal">{t.badge}</span>
                  )}
                </div>
                <p className="text-micro text-muted-foreground/70 normal-case tracking-normal truncate mt-0.5">{t.tagline}</p>
                {/* Stats row */}
                <div className="flex items-center gap-3 mt-1.5 text-micro text-muted-foreground/80 normal-case tracking-normal tabular">
                  <span>📍 {locCount}</span>
                  <span>👥 {userCount}</span>
                  <span>🧠 {memory}</span>
                  <span className="text-veltra-emerald">{t.screensEnabled.length} screens</span>
                </div>
              </div>
              {isActive && <Check className="h-3.5 w-3.5 text-veltra-emerald flex-shrink-0" />}
            </DropdownMenuItem>
          );
        })}
        <DropdownMenuSeparator />
        <p className="text-micro text-muted-foreground/60 normal-case tracking-normal px-3 py-2 leading-relaxed">
          Switching tier updates the visible screens + location count in real time.
        </p>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
