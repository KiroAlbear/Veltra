"use client";

import { useEffect, useState } from "react";
import { useVeltra } from "@/lib/veltra-store";
import {
  Dialog,
  DialogContent,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
  CommandSeparator,
} from "@/components/ui/command";
import {
  Briefcase,
  Users,
  CalendarClock,
  Activity,
  RotateCcw,
  Search,
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export function CommandPalette() {
  const [open, setOpen] = useState(false);
  const setView = useVeltra((s) => s.setView);
  const selectPatient = useVeltra((s) => s.selectPatient);
  const patients = useVeltra((s) => s.patients);
  const resetDemo = useVeltra((s) => s.resetDemo);
  const { toast } = useToast();

  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === "k") {
        e.preventDefault();
        setOpen((o) => !o);
      }
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, []);

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogContent className="p-0 overflow-hidden border-0 veltra-shadow-lg veltra-glass-strong max-w-xl" showCloseButton={false}>
        <DialogTitle className="sr-only">Command Palette</DialogTitle>
        <DialogDescription className="sr-only">Search or jump to any action, patient, or screen.</DialogDescription>
        <Command className="bg-transparent">
          <CommandInput placeholder="Search or jump to..." className="h-12" />
          <CommandList className="max-h-80 veltra-scrollbar">
            <CommandEmpty className="py-6 text-center text-caption text-muted-foreground">
              <span className="text-editorial-italic">Nothing found.</span>
            </CommandEmpty>

            <CommandGroup heading="Navigate" className="text-micro text-muted-foreground">
              <CommandItem
                onSelect={() => { setView("brief"); setOpen(false); }}
                className="py-2.5 cursor-pointer"
              >
                <Briefcase className="mr-3 h-4 w-4 text-veltra-emerald" />
                <span className="text-body">Today's Brief</span>
                <kbd className="ml-auto text-micro text-muted-foreground normal-case tracking-normal">1</kbd>
              </CommandItem>
              <CommandItem
                onSelect={() => { setView("patients"); setOpen(false); }}
                className="py-2.5 cursor-pointer"
              >
                <Users className="mr-3 h-4 w-4 text-veltra-emerald" />
                <span className="text-body">Patients</span>
                <kbd className="ml-auto text-micro text-muted-foreground normal-case tracking-normal">2</kbd>
              </CommandItem>
              <CommandItem
                onSelect={() => { setView("appointments"); setOpen(false); }}
                className="py-2.5 cursor-pointer"
              >
                <CalendarClock className="mr-3 h-4 w-4 text-veltra-emerald" />
                <span className="text-body">Appointments</span>
                <kbd className="ml-auto text-micro text-muted-foreground normal-case tracking-normal">3</kbd>
              </CommandItem>
              <CommandItem
                onSelect={() => { setView("timeline"); setOpen(false); }}
                className="py-2.5 cursor-pointer"
              >
                <Activity className="mr-3 h-4 w-4 text-veltra-emerald" />
                <span className="text-body">Timeline</span>
                <kbd className="ml-auto text-micro text-muted-foreground normal-case tracking-normal">4</kbd>
              </CommandItem>
            </CommandGroup>

            <CommandSeparator />

            <CommandGroup heading="Patients" className="text-micro text-muted-foreground">
              {patients.slice(0, 5).map((p) => (
                <CommandItem
                  key={p.id}
                  onSelect={() => { selectPatient(p.id); setOpen(false); }}
                  className="py-2.5 cursor-pointer"
                >
                  <Search className="mr-3 h-4 w-4 text-muted-foreground" />
                  <span className="text-body">{p.name}</span>
                  <span className="ml-auto text-caption text-muted-foreground">
                    {p.conditions[0] || "No conditions"}
                  </span>
                </CommandItem>
              ))}
            </CommandGroup>

            <CommandSeparator />

            <CommandGroup heading="Demo Controls" className="text-micro text-muted-foreground">
              <CommandItem
                onSelect={() => {
                  resetDemo();
                  toast({ title: "Demo reset", description: "All data restored." });
                  setOpen(false);
                }}
                className="py-2.5 cursor-pointer text-red-400"
              >
                <RotateCcw className="mr-3 h-4 w-4" />
                <span className="text-body">Reset demo data</span>
              </CommandItem>
            </CommandGroup>
          </CommandList>
        </Command>
      </DialogContent>
    </Dialog>
  );
}
