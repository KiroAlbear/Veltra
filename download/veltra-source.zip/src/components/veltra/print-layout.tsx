/**
 * VeltraPrintLayout — Professional branded print template
 * 
 * Wraps any content with Veltra header + footer for printing.
 * Usage: <VeltraPrintLayout title="Today's Brief" date="July 7, 2026">...</VeltraPrintLayout>
 */

interface VeltraPrintLayoutProps {
  title: string;
  date?: string;
  children: React.ReactNode;
}

export function VeltraPrintLayout({ title, date, children }: VeltraPrintLayoutProps) {
  const today = date || new Date().toLocaleDateString("en-US", {
    weekday: "long",
    year: "numeric",
    month: "long",
    day: "numeric",
  });

  return (
    <>
      {/* Print header — only visible when printing */}
      <div className="print-only veltra-print-header" style={{ display: "none" }}>
        <div className="logo">
          <div className="logo-mark">V</div>
          <span className="logo-text">Veltra</span>
        </div>
        <div className="doc-title">
          <h1>{title}</h1>
          <p>{today}</p>
        </div>
      </div>

      {/* Content */}
      <div className="veltra-print-body">{children}</div>

      {/* Print footer — only visible when printing */}
      <div className="print-only veltra-print-footer" style={{ display: "none" }}>
        <span className="copyright">© 2026 Veltra Technologies</span>
        <span className="tagline">Technology disappears. Care remains.</span>
        <span className="page-num">veltrahealth.co</span>
      </div>
    </>
  );
}
