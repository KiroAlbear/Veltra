"use client";

import { useVeltra } from "@/lib/veltra-store";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { Shield, History, LogIn, LogOut, RotateCcw, Calendar, Check, UserCheck, X, Stethoscope, DollarSign } from "lucide-react";
import { formatRelativeTime, formatDate } from "@/lib/veltra-store";
import { FadeIn, StaggerGroup, StaggerItem } from "./motion";

const ACTION_ICONS: Record<string, { icon: React.ElementType; tint: string }> = {
  "Logged in": { icon: LogIn, tint: "text-emerald-400 bg-emerald-500/10" },
  "Logged out": { icon: LogOut, tint: "text-slate-400 bg-slate-500/10" },
  "Logged in (demo)": { icon: LogIn, tint: "text-emerald-400 bg-emerald-500/10" },
  "Booked appointment": { icon: Calendar, tint: "text-violet-400 bg-violet-500/10" },
  "Confirmed appointment": { icon: Check, tint: "text-emerald-400 bg-emerald-500/10" },
  "Checked in patient": { icon: UserCheck, tint: "text-purple-400 bg-purple-500/10" },
  "Completed appointment": { icon: Stethoscope, tint: "text-emerald-400 bg-emerald-500/10" },
  "Cancelled appointment": { icon: X, tint: "text-red-400 bg-red-500/10" },
  "Reset demo data": { icon: RotateCcw, tint: "text-amber-400 bg-amber-500/10" },
  "Payment collected": { icon: DollarSign, tint: "text-emerald-400 bg-emerald-500/10" },
};

const ROLE_COLORS: Record<string, string> = {
  admin: "bg-rose-500/10 text-rose-300 border-rose-500/20",
  doctor: "bg-emerald-500/10 text-emerald-300 border-emerald-500/20",
  receptionist: "bg-amber-500/10 text-amber-300 border-amber-500/20",
  nurse: "bg-violet-500/10 text-violet-300 border-violet-500/20",
};

export function AuditScreen() {
  const auditLog = useVeltra((s) => s.auditLog);
  const currentUser = useVeltra((s) => s.currentUser);

  return (
    <div className="min-h-screen veltra-ambient">
      <div className="mx-auto max-w-4xl px-8 py-10 sm:px-12 sm:py-14">
        <FadeIn>
          <header className="mb-10">
            <div className="flex items-center gap-2 mb-3">
              <Shield className="h-3.5 w-3.5 text-veltra-emerald" />
              <span className="text-micro text-veltra-emerald">Audit Log</span>
            </div>
            <h1 className="text-[2.5rem] leading-[1.05] tracking-[-0.035em] text-foreground font-semibold">
              <span className="text-editorial-italic text-muted-foreground">Every action,</span>{" "}
              remembered.
            </h1>
            <p className="text-body text-muted-foreground mt-3">
              {auditLog.length} events logged · {currentUser?.name || "System"} viewing
            </p>
          </header>
        </FadeIn>

        <FadeIn delay={0.1}>
          <Card className="veltra-shadow border-0 bg-card/50 backdrop-blur-sm overflow-hidden">
            <StaggerGroup>
              {auditLog.length === 0 ? (
                <div className="px-6 py-16 text-center">
                  <div className="mx-auto h-10 w-10 rounded-full bg-muted/50 flex items-center justify-center mb-3">
                    <History className="h-4 w-4 text-muted-foreground" />
                  </div>
                  <p className="text-editorial-italic text-body text-muted-foreground">
                    Nothing yet. The log starts with the next action.
                  </p>
                </div>
              ) : (
                auditLog.map((entry, idx) => {
                  const cfg = ACTION_ICONS[entry.action] || { icon: History, tint: "text-slate-400 bg-slate-500/10" };
                  const Icon = cfg.icon;
                  return (
                    <StaggerItem key={entry.id}>
                      <div
                        className={cn(
                          "flex items-center gap-4 px-6 py-4 veltra-transition hover:bg-foreground/[0.03]",
                          idx !== auditLog.length - 1 && "border-b border-border/40"
                        )}
                      >
                        <div className={cn("flex-shrink-0 h-8 w-8 rounded-full flex items-center justify-center", cfg.tint)}>
                          <Icon className="h-3.5 w-3.5" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-body font-medium text-foreground">
                            {entry.action}
                          </p>
                          <p className="text-caption text-muted-foreground truncate mt-0.5">
                            {entry.target}
                          </p>
                        </div>
                        <div className="flex items-center gap-3 flex-shrink-0">
                          <Badge variant="outline" className={cn("text-micro font-medium border normal-case tracking-normal", ROLE_COLORS[entry.userRole])}>
                            {entry.userRole}
                          </Badge>
                          <div className="text-right">
                            <p className="text-caption font-medium text-foreground">{entry.userName}</p>
                            <p className="text-micro text-muted-foreground/70 normal-case tracking-normal mt-0.5">
                              {formatRelativeTime(entry.timestamp)} · {formatDate(entry.timestamp)}
                            </p>
                          </div>
                        </div>
                      </div>
                    </StaggerItem>
                  );
                })
              )}
            </StaggerGroup>
          </Card>
        </FadeIn>

        <FadeIn delay={0.2}>
          <p className="text-center mt-8 text-editorial-italic text-muted-foreground/50 text-sm">
            Accountability is not a feature. It is what separates a Chief of Staff from a tool.
          </p>
        </FadeIn>
      </div>
    </div>
  );
}
